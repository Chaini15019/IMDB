<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>
<body>

<div class="container">

	<div class="heading">
		<div class="logo">
			<img src="imdb.jpe" alt="Fjords" width=100% height=100% >
		</div>
		<h>IMDB </h>

	</div>

	<div class="icon-bar">
	<a class="active" href="www.imdb.com"><i>Home</i></a> 
	  <a href="#"><i>Insert</i></a> 
	  <a href="#"><i>Query</i></a> 
	</div>  

	<div class="footer">
		<form id="searchbox" action="">
		    <input id="search" type="text" placeholder="Type here">
		    <input id="submit" type="submit" value="Search">
		</form>
	</div>

</div>
</body>
</html>
